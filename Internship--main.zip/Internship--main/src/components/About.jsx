import React from "react";

export default function About(){
  return(
    <div>
    <h2> Welcome to About page</h2>
    </div>
)}

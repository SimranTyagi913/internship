import React from "react";

export default function Address(){
    return(
    <div>
        <p>xyz road,xyz city</p>
    </div>
    )
}
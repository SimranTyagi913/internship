import React from "react";

export default function ContactUs(){
    return(
    <div>
        <p>Call us at:9978675645</p>
        <p>Mail us at:axc@gmail.com</p>
    </div>
    )
}
import React from "react";

export default function Home(){
  return(
        <div>
        <h2>Welcome to home page</h2>
        </div>
 )
}
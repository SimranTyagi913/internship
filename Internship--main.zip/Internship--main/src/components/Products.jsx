import React from "react";

export default function Products(){
    return(
    <div>
        <h2>Welcome to Products</h2>
    </div>
    )
}